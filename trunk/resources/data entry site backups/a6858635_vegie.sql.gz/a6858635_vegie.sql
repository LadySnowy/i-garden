-- MySQL dump 10.13  Distrib 5.1.57, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: a6858635_vegie
-- ------------------------------------------------------
-- Server version	5.1.57
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plants`
--

DROP TABLE IF EXISTS `plants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plants` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `how_many` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `water_how_much` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `water_how_often` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `soil_temp` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `air_temp` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `sunlight` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `root_depth` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `min_spacing` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `growing_area` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `common_pests` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `organic_pest_control` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `inorganic_pest_control` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `plants_keep_pests_away` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `type` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `flower_size` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `flower_color` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `flower_scent` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `language_of_flowers` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `life_cycle` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `soil_nitrogen` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `soil_phosphorus` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `soil_potassium` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `soil_ph` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `soil_texture` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `calories` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `vitamins` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `yield_per_plant` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `edible_part` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `start` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `harden` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `transplant` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `harvest` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `image_url` mediumtext COLLATE latin1_general_ci,
  `companions` mediumtext COLLATE latin1_general_ci,
  `antagonists` mediumtext COLLATE latin1_general_ci,
  UNIQUE KEY `name` (`name`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plants`
--

LOCK TABLES `plants` WRITE;
/*!40000 ALTER TABLE `plants` DISABLE KEYS */;
INSERT INTO `plants` VALUES (6,'artichoke, jerusalem',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,'Corn',NULL,NULL,NULL,'60-95','60-75',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `plants` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-11-13  8:31:59
