<html>
<body>

<?php

$mysql_host = "mysql12.000webhost.com";
$mysql_database = "a6858635_vegie";
$mysql_user = "a6858635_vegie";
$mysql_password = "ji394su3";


$db = mysql_connect($mysql_host,$mysql_user,$mysql_password);

if (!$db) {
die("Error connecting.");
}


mysql_select_db($mysql_database);

if($_GET['field']=="name")
{
mysql_query("INSERT INTO plants (".addslashes($_GET['field']).") VALUES ('".$_GET['value']."')");
}
else
{
$query = "UPDATE plants SET ".addslashes($_GET['field'])." = '".$_GET['value']."' where name = '".$_GET['plant']."'";
echo $query;
mysql_query($query);
}


mysql_close($db);
	
header('Location:index.php');

?>


</body>
</html>

