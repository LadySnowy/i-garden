<?php 

$mysql_host = "mysql12.000webhost.com";
$mysql_database = "a6858635_vegie";
$mysql_user = "a6858635_vegie";
$mysql_password = "ji394su3";


$db = mysql_connect($mysql_host,$mysql_user,$mysql_password);

if (!$db) {
die("Error connecting.");
}


mysql_select_db($mysql_database);


$result = mysql_query("Select name from plants order by name asc");


?>


<html>

<head>
<LINK href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="content">
<a href="index.php">Back to Home</a><br />
<br />
<form action="form.php" method="get">
Plant: <select name="plant">
<?php 

while($row = mysql_fetch_array($result))
{
   echo "<option value=\"".$row['name']."\">".$row['name']."</option>";
}
?>
</select>
<br />
Field:
<select name="field">
  <option value="how_many">How Many to Plant (Death Rate)</option>
  <option value="water_how_much">How Much Water</option>
  <option value="water_how_often">Water: How Often</option>
  <option value="soil_temp">Soil Temperature</option>
  <option value="air_temp">Air Temperature</option>
  <option value="sunlight">Sunlight Requirement</option>
  <option value="root_depth">Root Depth</option>
  <option value="min_spacing">Min Spacing</option>
  <option value="growing_area">Growing Area</option>
  <option value="common_pests">Common Pests</option>
  <option value="organic_pest_control">Organic Pest Control</option>
  <option value="inorganic_pest_control">Inorganic Pest Control</option>
  <option value="plants_keep_pests_away">Plants that keep away pests</option>
  <option value="type">Plant Type</option>
  <option value="flower_size">Flower Size</option>
  <option value="flower_color">Flower Color</option>
  <option value="flower_scent">Flower Scent</option>
  <option value="language_of_flowers">Langue of Flowers</option>
  <option value="life_cycle">Life Cycle</option>
  <option value="soil_nitrogen">Nitrogen</option>
  <option value="soil_phosphorus">Phosphorus</option>
  <option value="soil_potassium">Potassium</option>
  <option value="soil_ph">Soil pH</option>
  <option value="soil_texture">Texture</option>
  <option value="calories">Calories</option>
  <option value="vitamins">Vitamins</option>
  <option value="yield_per_plant">Yield per plant</option>
  <option value="edible_part">Edible Part</option>
  <option value="start">When to Start the seeds</option>
  <option value="harden">When to harden the plants</option>
  <option value="transplant">When to transplant</option>
  <option value="harvest">When to harvest</option>
  <option value="image_url">Image</option>
  <option value="companions">Companions</option>
  <option value="antagonists">Antagonists</option>
</select><br />
data: <input type="text" name="value"><br />
<input type="submit" value="Submit">
</form>

</div>
</body>
</html>	


<?php 
mysql_close($db);

?>