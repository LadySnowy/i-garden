<html>

<head>
<LINK href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="content">

<div>
<a href="create.php">Create new plant</a><a href="update.php">Update a plant</a>
</div>
<br />
<br />
<div>
<?php 
$mysql_host = "mysql12.000webhost.com";
$mysql_database = "a6858635_vegie";
$mysql_user = "a6858635_vegie";
$mysql_password = "ji394su3";


$db = mysql_connect($mysql_host,$mysql_user,$mysql_password);

if (!$db) {
die("Error connecting.");
}


mysql_select_db($mysql_database);

$result = mysql_query("select * from plants order by name asc");

?>

<table>
<tr id="head">
  <td>Name</td>
  <td>How Many to Plant (Death Rate)</td>
  <td>How Much Water</td>
  <td>Water: How Often</td>
  <td>Soil Temperature</td>
  <td>Air Temperature</td>
  <td>Sunlight Requirement</td>
  <td>Root Depth</td>
  <td>Min Spacing</td>
  <td>Growing Area</td>
  <td>Common Pests</td>
  <td>Organic Pest Control</td>
  <td>Inorganic Pest Control</td>
  <td>Plants that keep away pests</td>
  <td>Plant Type</td>
  <td>Flower Size</td>
  <td>Flower Color</td>
  <td>Flower Scent</td>
  <td>Langue of Flowers</td>
  <td>Life Cycle</td>
  <td>Nitrogen</td>
  <td>Phosphorus</td>
  <td>Potassium</td>
  <td>Soil pH</td>
  <td>Texture</td>
  <td>Calories</td>
  <td>Vitamins</td>
  <td>Yield per plant</td>
  <td>Edible Part</td>
  <td>When to Start the seeds</td>
  <td>When to harden the plants</td>
  <td>When to transplant</td>
  <td>When to harvest</td>
  <td>Image</td>
  <td>Companions</td>
  <td>Antagonists</td>
</tr>

<?php

while($row = mysql_fetch_array($result))
{
  echo "<tr>";
  echo "<td>".$row['name']."</td>
  <td>".$row['how_many']."</td>
  <td>".$row['water_how_much']."</td>
  <td>".$row['water_how_often']."</td>
  <td>".$row['soil_temp']."</td>
  <td>".$row['air_temp']."</td>
  <td>".$row['sunlight']."</td>
  <td>".$row['root_depth']."</td>
  <td>".$row['min_spacing']."</td>
  <td>".$row['growing_are']."</td>
  <td>".$row['common_pests']."</td>
  <td>".$row['organic_pest_control']."</td>
  <td>".$row['inorganic_pest_control']."</td>
  <td>".$row['plants_keep_pests_away']."</td>
  <td>".$row['type']."</td>
  <td>".$row['flower_size']."</td>
  <td>".$row['flower_color']."</td>
  <td>".$row['flower_scent']."</td>
  <td>".$row['language_of_flowers']."</td>
  <td>".$row['life_cycle']."</td>
  <td>".$row['soil_nitrogen']."</td>
  <td>".$row['soil_phosphorus']."</td>
  <td>".$row['soil_potassium']."</td>
  <td>".$row['soil_ph']."</td>
  <td>".$row['soil_texture']."</td>
  <td>".$row['calories']."</td>
  <td>".$row['vitamins']."</td>
  <td>".$row['yield_per_plant']."</td>
  <td>".$row['edible_part']."</td>
  <td>".$row['start']."</td>
  <td>".$row['harden']."</td>
  <td>".$row['transplant']."</td>
  <td>".$row['harvest']."</td>
  <td><a href=\"".$row['image_url']."\">".$row['image_url']."</a></td>
  <td>".$row['companions']."</td>
  <td>".$row['antagonists']."</td>";
  echo "</tr>";
}

mysql_close($db);
?>


</table>
</div>

</div>
</body>

</html>