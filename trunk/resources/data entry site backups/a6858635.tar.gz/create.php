<html>

<head>
<LINK href="style.css" rel="stylesheet" type="text/css">
</head>

<body>
<div class="content">
<a href="index.php">Back to Home</a><br />
<br />
<form action="form.php" method="get">
name: <input type="text" name="value"><br />
<input type="hidden" name="field" value="name">
<input type="submit" value="Submit">
</form>

</div>
</body>
</html>